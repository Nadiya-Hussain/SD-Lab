echo "The command is $0"
echo "The first argument is $#"
echo "The second argument is $0"
echo "The third argument is $*"
echo "The fourth arhument is $@"

