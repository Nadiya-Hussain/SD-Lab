n=1
while [ $n -le 10 ]
do
 echo $n
 n=`expr $n + 1`
done
