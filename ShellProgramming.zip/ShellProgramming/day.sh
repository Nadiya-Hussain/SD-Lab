if [ "$1" == "Monday" ]
 then
     echo "The type argument is Monday."
elif [ "$1" == "Tuesday" ]
 then
     echo "Typed argument is tuesday."
else
   echo "Typed argument is neither Monay nor Tuesday."
fi

