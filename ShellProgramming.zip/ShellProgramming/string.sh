var="test string"
newvar="Value of var is $var"
echo $newvar
