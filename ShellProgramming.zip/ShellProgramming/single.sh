var='test string'
newvar='value of var is $var'
echo $newvar
