echo "Enter character: "
read ch
if ( $ch == 'a' -o $ch == 'A' -o $ch == 'e' -o $ch == 'E' -o $ch == 'i' -o $ch == 'I' -o $ch =='o' -o $ch=='O' -o $ch == 'u' -o $ch == 'U' )
then
echo "vowel"
else 
echo "Consonant"
fi

