echo -e "Enter a number:"
read a
n=$(($a%2))
if [ $n -eq 0 ]
then
echo "$a is even"
else
echo "$a is odd"
fi
